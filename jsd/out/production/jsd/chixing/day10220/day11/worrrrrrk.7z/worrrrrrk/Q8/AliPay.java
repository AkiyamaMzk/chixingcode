package chixing.day11.worrrrrrk.Q8;

public class AliPay implements IPayment{
    private AliPay aliPay=new AliPay();
    private void AliPay(){}
    public AliPay getInstance(){
        return aliPay;
    }
    @Override
    public void pay(double amount) {
        System.out.println("AliPay:"+amount);
    }
}
