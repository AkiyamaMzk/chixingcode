package chixing.day10220.day15.work.Q4;

import chixing.day10220.day13.echiwork.Q5.ProductWithBrand;

public class Phone extends ProductWithBrand{

    public Phone(String brand,String name, double price) {
        super(name, price, brand);
        //TODO Auto-generated constructor stub
    }
    
}
