package chixing.day09_static_interface.interfaces.homework.Q6;

public class OnlineOrder extends Order{


    @Override
    public String getOrderType() {
        return "OnlineOrder";
    }
}
