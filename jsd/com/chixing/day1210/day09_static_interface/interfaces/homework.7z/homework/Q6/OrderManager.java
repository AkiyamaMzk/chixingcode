package chixing.day09_static_interface.interfaces.homework.Q6;

public class OrderManager {
    static int ordersum=0;
    public static void printSummary(Order o){
        System.out.println(ordersum);
    }
}
