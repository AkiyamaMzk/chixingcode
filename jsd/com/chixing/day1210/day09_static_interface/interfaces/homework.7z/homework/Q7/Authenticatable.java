package chixing.day09_static_interface.interfaces.homework.Q7;

public interface Authenticatable {
    public boolean login(String username, String password);

}
