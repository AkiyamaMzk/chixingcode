package chixing.day10.workwork;

public class Outer {
    private String  message = "Hello";
    public class Inner{
        public void printMessage(){
            System.out.println(message);
        }
    }

}
