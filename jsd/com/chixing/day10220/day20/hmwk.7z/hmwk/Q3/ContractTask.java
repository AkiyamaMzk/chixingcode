package chixing.day10220.day20.hmwk.Q3;

public class ContractTask implements Runnable {

    @Override
    public void run() {
        
    }

}
