package chixing.day09_static_interface.interfaces.homework.Q4;

public interface Downloadable {
    public void download(String url);
}
