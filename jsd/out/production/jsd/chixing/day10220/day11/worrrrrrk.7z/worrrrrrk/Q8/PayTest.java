package chixing.day11.worrrrrrk.Q8;

public class PayTest {
    public static void main(String[] args) {
        IPayment pay1=new WeChatPay();
        pay1.pay(100);
    }


}
