package chixing.day09_static_interface.interfaces.homework.Q6;

public interface Orderable {
    public void calculateTotal();
}
