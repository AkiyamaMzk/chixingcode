package chixing.day10.workwork.Q19;

public class FlushWater implements Water{
    @Override
    public void information() {
        System.out.println("这是冲厕水");
    }
}
