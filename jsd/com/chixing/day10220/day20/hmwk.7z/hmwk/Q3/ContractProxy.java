package chixing.day10220.day20.hmwk.Q3;

import chixing.dayNull.SimpleProxy;

public class ContractProxy extends SimpleProxy{

    public ContractProxy(Object target) {
        super(target);
    }

}
