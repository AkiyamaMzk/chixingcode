package chixing.day10.workwork.Q19;

public interface Water {
    void information();

}
