package chixing.day09_static_interface.interfaces.homework.Q4;

public interface Playable {
    public void play();
    public void stop();
}
