package chixing.day11.worrrrrrk.Q9;

import java.time.LocalDateTime;
import java.util.Date;

public class LeaveRequest extends ApprovalRequest{

    public LeaveRequest(String applicantName, LocalDateTime applicantTime, String description) {
        super(applicantName, applicantTime, description);
    }
}
