package chixing.day10220.day13.echiwork.Q7;

public interface MyCompare {
    public int compare(Object o);
}
