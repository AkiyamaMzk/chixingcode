package chixing.day11.worrrrrrk.Q8;

public interface IPayment {
    void pay(double amount);
}
