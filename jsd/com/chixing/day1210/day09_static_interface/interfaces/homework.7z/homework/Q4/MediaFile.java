package chixing.day09_static_interface.interfaces.homework.Q4;

public abstract class MediaFile {
    public String fileName;
    public int fileSize;

    public MediaFile(String fileName, int fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }
}
