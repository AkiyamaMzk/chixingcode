package chixing.day10.workwork.Q17;

public class OrderTest {
    public static void main(String[] args) {
        Order personalOrder = new PersonalOrder(100);
        Order enterpriseOrder = new EnterpriseOrder(5000);
        System.out.println(personalOrder);
        System.out.println(enterpriseOrder);

    }
}
