package chixing.day11.worrrrrrk.Q9;

import java.time.LocalDateTime;
import java.util.Date;

public class ExpenseRequest extends ApprovalRequest{

    public ExpenseRequest(String applicantName, LocalDateTime applicantTime, String description) {
        super(applicantName, applicantTime, description);
    }
}
