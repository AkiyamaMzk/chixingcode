package chixing.day11.worrrrrrk.Q9;

public interface Approver {
    void approve(ApprovalRequest request);
}
