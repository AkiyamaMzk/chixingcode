package chixing.day10.workwork.Q17;

public interface Order {
    public Order[] split();
    public void orderadd();

}
